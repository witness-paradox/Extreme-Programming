from flask import Flask, request, jsonify,send_from_directory
import math
import tkinter
import tkinter as tk
import numpy as np
import re
import sqlite3

##主函数：

app = Flask(__name__)
@app.route('/')
def index():
    return app.send_static_file('normal.html')

@app.route('/page1')
def page1():
    return send_from_directory('static', 'cal.html')

@app.route('/page2')
def page2():
    return send_from_directory('static', 'interest.html')

@app.route('/page3')
def page3():
    return send_from_directory('static', 'loan_interest.html')

@app.route('/page4')
def page4():
    return send_from_directory('static', 'sql.html')

@app.route('/page5')
def page5():
    return send_from_directory('static', 'sql2.html')

##以上为前后端连接，引入前端文件

@app.route('/process-text', methods=['POST'])
def process_text():
    data = request.json
    text_all = data.get('text')
    print('Received text:', text_all)
    try:
        result = re.sub(r'(sin|cos|tan|pi|e)\b', r'math.\1', text_all)
        result = re.sub(r'ln', 'np.log', result)
        result = re.sub(r'lg', 'np.log10', result)
        result = re.sub(r'\^', '**', result)
        result = re.sub(r'sqrt\((.*?)\)', r'\1**0.5', result)
        result = str(eval(result))
    except Exception as e:
        result = "error"
    return jsonify({'result': f' { result }'})

##实现计算器

@app.route('/calculate-interest', methods=['POST'])
def calculate_interest():
    data = request.get_json()
    print(data)
    amount = data.get('amount')
    duration = data.get('duration')  # In years for fixed deposits
    rate_type = data.get('type', 'current')
    # Open a new database connection to retrieve the rate
    conn = sqlite3.connect('interest_rates.db')##实现与后端数据库的连接从而调用数据库数据
    cursor = conn.cursor()

    # Retrieve the rate based on the deposit type
    if rate_type == 'current':
        cursor.execute('SELECT rate FROM interest_rates WHERE term = "current"')
    else:
        # Convert years to the corresponding term in months
        term = str(duration)
        cursor.execute('SELECT rate FROM interest_rates WHERE term = ?', (term,))

    # Fetch the rate
    rate_record = cursor.fetchone()
    conn.close()

    # If rate is not found, return an error response
    if not rate_record:
        return jsonify({'error': 'Rate not found for the specified term'}), 404

    # Calculate the interest
    rate = rate_record[0]

    print(duration,rate,amount)

    if rate_type == 'fixed':
        interest = float(amount) * (float(rate) / 100) * float(duration)/12
    if rate_type == 'current':
        interest = float(amount) * (float(rate) / 100) * float(duration)
    return jsonify({'interest': interest})

##实现存款利率

@app.route('/calculate_loan_interest', methods=['POST'])
def calculate_loan_interest():
    data = request.get_json()
    print(data)
    amount = data.get('amount')
    term = data.get('term')
    term=int(term)

    if (term<=6):##0到6个月利率
        conn = sqlite3.connect('interest_rates.db')
        cursor = conn.cursor()
        cursor.execute('SELECT rate FROM loan_interest_rates WHERE term = ?', (6,))##与存款不同，贷款利率都是从数据库里调取的
        rate_record = cursor.fetchone()
        conn.close()
        rate = rate_record[0]
        loan_interest = float(amount) * (float(rate) / 100) * float(term)/12

    if (12>=term>6):##六个月到十二个月利率
        conn = sqlite3.connect('interest_rates.db')
        cursor = conn.cursor()
        cursor.execute('SELECT rate FROM loan_interest_rates WHERE term = ?', (12,))
        rate_record = cursor.fetchone()
        conn.close()
        rate = rate_record[0]
        loan_interest = float(amount) * (float(rate) / 100) * float(term)/12

    if (36>=term>12):##一到三年利率
        conn = sqlite3.connect('interest_rates.db')
        cursor = conn.cursor()
        cursor.execute('SELECT rate FROM loan_interest_rates WHERE term = ?', (24,))
        rate_record = cursor.fetchone()
        conn.close()
        rate = rate_record[0]
        loan_interest = float(amount) * (float(rate) / 100) * float(term)/12

    if (60>=term>36):##三到五年利率
        conn = sqlite3.connect('interest_rates.db')
        cursor = conn.cursor()
        cursor.execute('SELECT rate FROM loan_interest_rates WHERE term = ?', (36,))
        rate_record = cursor.fetchone()
        conn.close()
        rate = rate_record[0]
        loan_interest = float(amount) * (float(rate) / 100) * float(term)/12

    if (term>60):##五年以上利率
        conn = sqlite3.connect('interest_rates.db')
        cursor = conn.cursor()
        cursor.execute('SELECT rate FROM loan_interest_rates WHERE term = ?', (60,))
        rate_record = cursor.fetchone()
        conn.close()
        rate = rate_record[0]
        loan_interest = float(amount) * (float(rate) / 100) * float(term)/12

    if not rate_record:
        return jsonify({'error': 'Rate not found for the specified term'}), 404


    print(loan_interest)
    return jsonify({'loan_interest': loan_interest})
@app.route('/get-interest-rate', methods=['GET'])
def get_interest_rate():
    year = request.args.get('year')
    rate = retrieve_interest_rate_from_db(year)
    if rate is not None:
        return jsonify({'year': year, 'rate': rate})
    else:
        return jsonify({'message': '未找到相应的利率'})

##调用获取利率函数以及对应年份，无对应数据时报错

def retrieve_interest_rate_from_db(year):
    conn = sqlite3.connect('interest_rates.db')
    cursor = conn.cursor()
    cursor.execute('SELECT rate FROM interest_rates WHERE term = ?', (year,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

##从数据库中调取具体利率

@app.route('/update-interest-rate', methods=['POST'])
def update_interest_rate():
    data = request.get_json()
    year = data['year']
    new_rate = data['newRate']
    success = update_interest_rate_in_db(year, new_rate)
    if success:
        return jsonify({'message': f'成功更新了{year}个月的利率'})
    else:
        return jsonify({'message': f'更新{year}个月的利率时出现问题'})

##将输入框中输入的利率数据更新

def update_interest_rate_in_db(year, new_rate):
    conn = sqlite3.connect('interest_rates.db')
    cursor = conn.cursor()
    try:
        cursor.execute('UPDATE interest_rates SET rate = ? WHERE term = ?', (new_rate, year))
        conn.commit()
        return True
    except:
        return False
    finally:
        conn.close()

##将具体输入的数据写到数据库里

@app.route('/get-linterest-rate', methods=['GET'])
def get_linterest_rate():
    year = request.args.get('year')
    if (int(year) <= 6):
        year=6;
    if (6<int(year) <= 12):
        year=12;
    if (12<int(year) <= 36):
        year=24;
    if (36<int(year) <= 60):
        year=36;
    if (6<int(year) <= 12):
        year=60;
    rate = retrieve_linterest_rate_from_db(year)
    year = request.args.get('year')
    if rate is not None:
        return jsonify({'year': year, 'rate': rate})
    else:
        return jsonify({'message': '未找到相应的利率'})

##确定具体的利率等级

def retrieve_linterest_rate_from_db(year):

        conn = sqlite3.connect('interest_rates.db')
        cursor = conn.cursor()
        cursor.execute('SELECT rate FROM loan_interest_rates WHERE term = ?', (year,))
        result = cursor.fetchone()
        conn.close()
        return result[0] if result else None

##获取贷款利率

@app.route('/update-linterest-rate', methods=['POST'])
def update_linterest_rate():
    data = request.get_json()
    year = data['year']
    new_rate = data['newRate']
    if (int(year) <= 6):
        year=6;
    if (6<int(year) <= 12):
        year=12;
    if (12<int(year) <= 36):
        year=24;
    if (36<int(year) <= 60):
        year=36;
    if (6<int(year) <= 12):
        year=60;
    success = update_linterest_rate_in_db(year, new_rate)
    year = data['year']
    if success:
        return jsonify({'message': f'成功更新了{year}个月的利率'})
    else:
        return jsonify({'message': f'更新{year}个月的利率时出现问题'})

##确定贷款的具体利率等级并且更新

def update_linterest_rate_in_db(year, new_rate):
    conn = sqlite3.connect('interest_rates.db')
    cursor = conn.cursor()
    try:
        cursor.execute('UPDATE loan_interest_rates SET rate = ? WHERE term = ?', (new_rate, year))
        conn.commit()
        return True
    except:
        return False
    finally:
        conn.close()

if __name__ == '__main__':
    app.run(debug=True)
