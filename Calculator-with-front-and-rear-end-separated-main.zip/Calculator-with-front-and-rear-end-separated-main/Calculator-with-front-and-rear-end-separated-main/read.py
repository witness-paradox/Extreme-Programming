import sqlite3
conn = sqlite3.connect('interest_rates.db')
cursor = conn.cursor()
#term = str(int(duration) * 12)
term = '36'
# Retrieve the rate based on the deposit type
#cursor.execute('SELECT rate FROM interest_rates WHERE term = "current"')
cursor.execute('SELECT rate FROM interest_rates WHERE term = ?', (term,))

rate_record = cursor.fetchone()
print(rate_record)
conn.close()


##此程序用于测试数据库是否被更改
