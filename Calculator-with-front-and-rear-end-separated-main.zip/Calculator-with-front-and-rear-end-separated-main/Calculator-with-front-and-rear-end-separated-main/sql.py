import sqlite3
##后端数据库

# Define the interest rates
interest_rates = {
    'current': 0.50,
    '3': 2.85,  # 3 months
    '6': 3.05,  # 6 months
    '12': 3.25, # 1 year
    '24': 4.15, # 2 years
    '36': 4.75, # 3 years
    '60': 5.25  # 5 years
}
loan_interest_rates = {
    '6': 5.85,  # 6 months
    '12': 6.30, # 1 year
    '24': 6.41, # 1-3 years
    '36': 6.65, # 3-5 years
    '60': 6.80  # 5 years
}


# Connect to the SQLite database
conn = sqlite3.connect('interest_rates.db')

# Create a cursor object
cursor = conn.cursor()

# Create the table to store interest rates
cursor.execute('''
CREATE TABLE IF NOT EXISTS interest_rates (
    term TEXT PRIMARY KEY,
    rate REAL NOT NULL
)
''')
cursor.execute('''
CREATE TABLE IF NOT EXISTS loan_interest_rates (
    term TEXT PRIMARY KEY,
    rate REAL NOT NULL
)
''')
# Clear the table before inserting new rates
cursor.execute('DELETE FROM interest_rates')

# Insert new rates into the table
for term, rate in interest_rates.items():
    cursor.execute('INSERT INTO interest_rates (term, rate) VALUES (?, ?)', (term, rate))
for term, rate in loan_interest_rates.items():
    cursor.execute('INSERT INTO loan_interest_rates (term, rate) VALUES (?, ?)', (term, rate))

# Commit the transaction and close the connection
conn.commit()
conn.close()
